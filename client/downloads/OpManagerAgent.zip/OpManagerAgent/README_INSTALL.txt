==================================================================
  ManageEngine OpManager Central - Windows Agent Setup Instructions
==================================================================

IMPORTANT PREREQUISITE:
For the OpManager Windows Agent to register with Central server (192.168.30.65:8060),
'OPMAgentServerInfo.json' MUST remain in the same folder as 'OpManagerAgent.exe' and 'OpManagerAgent.msi'.

Option 1 (Automated MSI Installer - Recommended):
1. Extract all files from this ZIP into a folder (e.g. C:\OpManagerAgent\).
2. Double-click 'OpManagerAgent.msi' (or 'OpManagerAgent.exe').
3. The agent will read OPMAgentServerInfo.json, connect to Central (192.168.30.65:8060),
   and start streaming Windows host telemetry.

Option 2 (Windows Background Service):
1. Right-click 'install_service.bat' and select 'Run as Administrator'.
2. The service 'OpManagerCentralAgent' will be registered and start automatically on boot.

Option 3 (Foreground Command-line Execution):
1. Open PowerShell or Command Prompt in this folder.
2. Run: .\OpManagerAgent.exe
